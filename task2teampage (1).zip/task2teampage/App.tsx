const TEAM_NAME = 'Team Page'

const members = [
  {
    id: '01',
    name: 'Firstname Lastname',
    role: 'Project Manager',
    blurb: '[Short blurb goes here]',
    photo: null, // paste image URL here
  },
  {
    id: '02',
    name: 'Firstname Lastname',
    role: 'Business Analyst',
    blurb: '[Short blurb goes here]',
    photo: null, // paste image URL here
  },
  {
    id: '03',
    name: 'Firstname Lastname',
    role: 'UX',
    blurb: '[Short blurb goes here]',
    photo: null, // paste image URL here
  },
  {
    id: '04',
    name: 'Firstname Lastname',
    role: 'Developer',
    blurb: '[Short blurb goes here]',
    photo: null, // paste image URL here
  },
  {
    id: '05',
    name: 'Firstname Lastname',
    role: 'Developer',
    blurb: '[Short blurb goes here]',
    photo: null, // paste image URL here
  },
]

function Avatar({ id, photo }: { id: string; photo: string | null }) {
  return (
    <div
      className="relative self-start flex items-center justify-center overflow-hidden"
      style={{
        width: 96,
        aspectRatio: '4/5',
        backgroundColor: 'var(--secondary)',
        borderRadius: 'var(--radius)',
      }}
    >
      {photo ? (
        <img src={photo} alt="" className="w-full h-full object-cover" />
      ) : (
        <>
          <svg width="36" height="36" viewBox="0 0 36 36" fill="none" xmlns="http://www.w3.org/2000/svg">
            <circle cx="18" cy="14" r="7" stroke="var(--muted-foreground)" strokeWidth="1.5" fill="none" />
            <path d="M4 34c0-7.732 6.268-14 14-14s14 6.268 14 14" stroke="var(--muted-foreground)" strokeWidth="1.5" fill="none" strokeLinecap="round" />
          </svg>
          <span
            className="absolute bottom-2 left-0 right-0 text-center text-xs"
            style={{ fontFamily: 'monospace', color: 'var(--muted-foreground)', opacity: 0.5 }}
          >
            {id}
          </span>
        </>
      )}
    </div>
  )
}

function MemberCard({ member }: { member: typeof members[0] }) {
  return (
    <article
      className="border-t pt-5 pb-6"
      style={{ borderColor: 'var(--border)' }}
    >
      <div className="grid gap-6" style={{ gridTemplateColumns: '96px 1fr' }}>
        <Avatar id={member.id} photo={member.photo} />

        {/* Info */}
        <div className="flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-3 mb-1.5">
              <h2
                className="leading-none"
                style={{
                  fontFamily: 'var(--font-display)',
                  fontWeight: 300,
                  fontSize: 'clamp(1.1rem, 2vw, 1.4rem)',
                  color: 'var(--foreground)',
                }}
              >
                {member.name}
              </h2>
              <span
                className="text-xs tracking-widest select-none"
                style={{ color: 'var(--muted-foreground)', fontFamily: 'monospace' }}
              >
                {member.id}
              </span>
            </div>

            <p
              className="mb-2 text-xs font-medium tracking-wide uppercase"
              style={{ color: 'var(--accent)', letterSpacing: '0.1em' }}
            >
              {member.role}
            </p>

            <p
              className="leading-relaxed"
              style={{
                color: 'var(--secondary-foreground)',
                fontSize: '0.8125rem',
              }}
            >
              {member.blurb}
            </p>
          </div>

        </div>
      </div>
    </article>
  )
}

export default function App() {
  return (
    <div
      className="min-h-screen"
      style={{ backgroundColor: 'var(--background)', color: 'var(--foreground)' }}
    >
      {/* Header */}
      <header
        className="sticky top-0 z-10 flex items-center justify-between px-8 py-4"
        style={{
          borderBottom: '1px solid var(--border)',
          backgroundColor: 'var(--background)',
          backdropFilter: 'blur(8px)',
        }}
      >
        <span
          className="text-xs tracking-[0.2em] uppercase"
          style={{ fontFamily: 'monospace', color: 'var(--muted-foreground)' }}
        >
          {TEAM_NAME}
        </span>
        <button
          className="text-xs tracking-[0.15em] uppercase px-3 py-1.5 transition-colors duration-200"
          style={{
            fontFamily: 'monospace',
            color: 'var(--muted-foreground)',
            border: '1px solid var(--border)',
            borderRadius: 'var(--radius)',
          }}
          onMouseEnter={e => {
            (e.currentTarget as HTMLButtonElement).style.color = 'var(--foreground)'
            ;(e.currentTarget as HTMLButtonElement).style.borderColor = 'rgba(232,230,224,0.3)'
          }}
          onMouseLeave={e => {
            (e.currentTarget as HTMLButtonElement).style.color = 'var(--muted-foreground)'
            ;(e.currentTarget as HTMLButtonElement).style.borderColor = 'var(--border)'
          }}
          onClick={() => {}}
        >
          Log out
        </button>
      </header>

      {/* Hero */}
      <section className="px-8 pt-10 pb-8" style={{ maxWidth: '900px' }}>
        <h1
          className="leading-none"
          style={{
            fontFamily: 'var(--font-display)',
            fontWeight: 300,
            fontSize: 'clamp(2rem, 5vw, 3.5rem)',
            letterSpacing: '-0.02em',
            color: 'var(--foreground)',
          }}
        >
          {TEAM_NAME}
        </h1>
      </section>

      {/* Divider */}
      <div className="mx-8" style={{ borderTop: '1px solid var(--border)' }} />

      {/* Team grid */}
      <main className="px-8 pb-12" style={{ maxWidth: '900px' }}>
        {members.map((member) => (
          <MemberCard key={member.id} member={member} />
        ))}
      </main>

    </div>
  )
}
