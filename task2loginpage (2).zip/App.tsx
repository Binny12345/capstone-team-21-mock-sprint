import { useState } from 'react'

type View = 'login' | 'create'

export default function App() {
  const [view, setView] = useState<View>('login')
  const [displayName, setDisplayName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [focused, setFocused] = useState<string | null>(null)
  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)
    // Simulate submission
    await new Promise(resolve => setTimeout(resolve, 1000))
    setIsSubmitting(false)
  }

  const handleGoogleSignIn = async () => {
    // Handle Google sign-in
  }

  const inputStyle = (name: string): React.CSSProperties => ({
    width: '100%',
    background: 'var(--secondary)',
    border: `1px solid ${focused === name ? 'var(--accent)' : 'var(--border)'}`,
    borderRadius: 'var(--radius)',
    color: 'var(--foreground)',
    fontSize: '0.875rem',
    fontFamily: "'Instrument Sans', sans-serif",
    fontWeight: 400,
    letterSpacing: '0.01em',
    padding: '10px 12px',
    outline: 'none',
    boxShadow: '0 1px 2px rgba(0, 0, 0, 0.1)',
    transition: 'border-color 0.2s ease',
    lineHeight: '1.25rem',
  })

  const labelStyle: React.CSSProperties = {
    display: 'block',
    fontSize: '0.875rem',
    fontWeight: 500,
    fontFamily: "'Instrument Sans', sans-serif",
    color: 'var(--foreground)',
    marginBottom: '6px',
  }

  const errorTextStyle: React.CSSProperties = {
    fontSize: '0.75rem',
    color: '#ef4444',
    marginTop: '4px',
  }

  return (
    <div
      style={{
        minHeight: '100vh',
        background: 'var(--background)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '24px',
        position: 'relative',
        overflow: 'hidden',
      }}
    >
      {/* Subtle grain texture overlay */}
      <div
        style={{
          position: 'absolute',
          inset: 0,
          backgroundImage:
            'url("data:image/svg+xml,%3Csvg viewBox=\'0 0 256 256\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cfilter id=\'noise\'%3E%3CfeTurbulence type=\'fractalNoise\' baseFrequency=\'0.9\' numOctaves=\'4\' stitchTiles=\'stitch\'/%3E%3C/filter%3E%3Crect width=\'100%25\' height=\'100%25\' filter=\'url(%23noise)\' opacity=\'0.04\'/%3E%3C/svg%3E")',
          opacity: 0.4,
          pointerEvents: 'none',
        }}
      />

      {/* Accent glow */}
      <div
        style={{
          position: 'absolute',
          top: '-20%',
          left: '50%',
          transform: 'translateX(-50%)',
          width: '600px',
          height: '400px',
          background: 'radial-gradient(ellipse at center, rgba(200,169,110,0.06) 0%, transparent 70%)',
          pointerEvents: 'none',
        }}
      />

      <div style={{ width: '100%', maxWidth: '400px', position: 'relative' }}>
        {/* Card */}
        <div
          style={{
            background: 'var(--card)',
            border: '1px solid var(--border)',
            borderRadius: 'calc(var(--radius) * 2)',
            padding: '40px 28px',
          }}
        >
          {/* Space-y-6 container */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
            {/* Heading - space-y-1 */}
            <div style={{ textAlign: 'center' }}>
              <h1
                style={{
                  fontFamily: "'Fraunces', serif",
                  fontSize: '1.75rem',
                  fontWeight: 700,
                  color: 'var(--accent)',
                  margin: '0 0 4px',
                  lineHeight: 1.2,
                  letterSpacing: '-0.025em',
                }}
              >
                {view === 'login' ? 'Sign in' : 'Create account'}
              </h1>
              <p
                style={{
                  fontSize: '0.875rem',
                  fontFamily: "'Instrument Sans', sans-serif",
                  color: 'var(--muted-foreground)',
                  margin: 0,
                  fontWeight: 400,
                }}
              >
                {view === 'login' ? 'Enter your credentials to continue' : 'Get started for free'}
              </p>
            </div>

            {/* Google Sign-in Button */}
            <button
              type="button"
              onClick={handleGoogleSignIn}
              style={{
                display: 'flex',
                width: '100%',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '12px',
                borderRadius: 'var(--radius)',
                border: '1px solid var(--border)',
                background: 'var(--secondary)',
                padding: '10px 16px',
                fontSize: '0.875rem',
                fontWeight: 500,
                fontFamily: "'Instrument Sans', sans-serif",
                color: 'var(--foreground)',
                boxShadow: '0 1px 2px rgba(0, 0, 0, 0.1)',
                cursor: 'pointer',
                transition: 'background-color 0.2s ease',
              }}
              onMouseEnter={(e) => (e.currentTarget.style.background = 'var(--card)')}
              onMouseLeave={(e) => (e.currentTarget.style.background = 'var(--secondary)')}
            >
              {/* Google SVG Icon */}
              <svg style={{ height: '16px', width: '16px' }} viewBox="0 0 24 24" aria-hidden="true">
                <path
                  d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                  fill="#4285F4"
                />
                <path
                  d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                  fill="#34A853"
                />
                <path
                  d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
                  fill="#FBBC05"
                />
                <path
                  d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
                  fill="#EA4335"
                />
              </svg>
              Continue with Google
            </button>

            {/* Divider - "or" */}
            <div style={{ position: 'relative' }}>
              <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center' }}>
                <span style={{ width: '100%', borderTop: '1px solid var(--border)' }} />
              </div>
              <div style={{ position: 'relative', display: 'flex', justifyContent: 'center' }}>
                <span
                  style={{
                    background: 'var(--card)',
                    padding: '0 8px',
                    fontSize: '0.75rem',
                    fontFamily: "'Instrument Sans', sans-serif",
                    textTransform: 'uppercase',
                    color: 'var(--muted-foreground)',
                  }}
                >
                  or
                </span>
              </div>
            </div>

            {/* Form - space-y-4 */}
            <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
              {/* Name field - Sign up only */}
              {view === 'create' && (
                <div>
                  <label htmlFor="displayName" style={labelStyle}>
                    Name
                  </label>
                  <input
                    id="displayName"
                    type="text"
                    autoComplete="name"
                    placeholder="Your full name"
                    value={displayName}
                    onChange={(e) => setDisplayName(e.target.value)}
                    onFocus={() => setFocused('displayName')}
                    onBlur={() => setFocused(null)}
                    style={inputStyle('displayName')}
                  />
                </div>
              )}

              {/* Email field - Sign up only */}
              {view === 'create' && (
                <div>
                  <label htmlFor="email" style={labelStyle}>
                    Email
                  </label>
                  <input
                    id="email"
                    type="email"
                    autoComplete="email"
                    placeholder="you@example.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    onFocus={() => setFocused('email')}
                    onBlur={() => setFocused(null)}
                    style={inputStyle('email')}
                  />
                </div>
              )}

              {/* Email field - Sign in (login uses email, not username) */}
              {view === 'login' && (
                <div>
                  <label htmlFor="email-login" style={labelStyle}>
                    Email
                  </label>
                  <input
                    id="email-login"
                    type="email"
                    autoComplete="email"
                    placeholder="you@example.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    onFocus={() => setFocused('email-login')}
                    onBlur={() => setFocused(null)}
                    style={inputStyle('email-login')}
                  />
                </div>
              )}

              {/* Password field */}
              <div>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '6px' }}>
                  <label htmlFor="password" style={{ ...labelStyle, marginBottom: 0 }}>
                    Password
                  </label>
                </div>
                <input
                  id="password"
                  type="password"
                  autoComplete={view === 'login' ? 'current-password' : 'new-password'}
                  placeholder={view === 'login' ? '••••••••' : 'Min. 8 characters, 1 uppercase, 1 number'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  onFocus={() => setFocused('password')}
                  onBlur={() => setFocused(null)}
                  style={inputStyle('password')}
                />
              </div>

              {/* Confirm password - Sign up only */}
              {view === 'create' && (
                <div>
                  <label htmlFor="confirmPassword" style={labelStyle}>
                    Confirm password
                  </label>
                  <input
                    id="confirmPassword"
                    type="password"
                    autoComplete="new-password"
                    placeholder="••••••••"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    onFocus={() => setFocused('confirmPassword')}
                    onBlur={() => setFocused(null)}
                    style={inputStyle('confirmPassword')}
                  />
                </div>
              )}

              {/* Submit Button */}
              <button
                type="submit"
                disabled={isSubmitting}
                style={{
                  width: '100%',
                  padding: '10px 16px',
                  background: 'var(--primary)',
                  color: 'var(--primary-foreground)',
                  border: 'none',
                  borderRadius: 'var(--radius)',
                  fontSize: '0.875rem',
                  fontWeight: 500,
                  fontFamily: "'Instrument Sans', sans-serif",
                  cursor: isSubmitting ? 'not-allowed' : 'pointer',
                  opacity: isSubmitting ? 0.5 : 1,
                  transition: 'background-color 0.2s ease',
                }}
                onMouseEnter={(e) => {
                  if (!isSubmitting) e.currentTarget.style.background = 'var(--secondary-foreground)'
                }}
                onMouseLeave={(e) => {
                  if (!isSubmitting) e.currentTarget.style.background = 'var(--primary)'
                }}
              >
                {isSubmitting
                  ? view === 'login'
                    ? 'Signing in…'
                    : 'Creating account…'
                  : view === 'login'
                    ? 'Sign in'
                    : 'Create account'}
              </button>
            </form>
          </div>
        </div>

        {/* Switch view */}
        <p
          style={{
            textAlign: 'center',
            marginTop: '24px',
            fontSize: '0.875rem',
            fontFamily: "'Instrument Sans', sans-serif",
            color: 'var(--muted-foreground)',
            fontWeight: 400,
          }}
        >
          {view === 'login' ? "Don't have an account? " : 'Already have an account? '}
          <button
            type="button"
            onClick={() => {
              setView(view === 'login' ? 'create' : 'login')
              setDisplayName('')
              setEmail('')
              setPassword('')
              setConfirmPassword('')
            }}
            style={{
              background: 'none',
              border: 'none',
              padding: 0,
              cursor: 'pointer',
              fontSize: '0.875rem',
              fontWeight: 500,
              fontFamily: "'Instrument Sans', sans-serif",
              color: 'var(--accent)',
              textDecoration: 'underline',
              textUnderlineOffset: '3px',
            }}
          >
            {view === 'login' ? 'Create one' : 'Sign in'}
          </button>
        </p>
      </div>
    </div>
  )
}